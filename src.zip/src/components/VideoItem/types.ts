export interface VideoProps {
  src: string;
  isActive: boolean;
}
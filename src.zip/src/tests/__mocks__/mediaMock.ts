const mediaMock = [
  { id: "1", type: "video", src: "/path/to/video1.mp4", title: "Whispers of Ipsum" },
  { id: "2", type: "video", src: "/path/to/video2.mp4", title: "Forest of Dolor" },
  { id: "3", type: "video", src: "/path/to/video3.mp4", title: "Mystic Adventures" },
  { id: "4", type: "video", src: "/path/to/video4.mp4", title: "Timeless Echoes" },
];

export default mediaMock;
